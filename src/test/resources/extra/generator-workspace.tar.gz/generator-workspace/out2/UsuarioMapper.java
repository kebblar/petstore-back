/*
 * Licencia:    Usted puede utilizar libremente este código
 *              para copiarlo, distribuirlo o modificarlo total
 *              o parcialmente siempre y cuando mantenga este
 *              aviso y reconozca la autoría del código al no
 *              modificar los datos establecidos en la mencion de "AUTOR".
 *
 * Proyecto:    petstore
 * Paquete:     io.kebblar.petstore.api.mapper
 * Modulo:      Usuario
 * Tipo:        interface 
 * Autor:       Gustavo A. Arellano
 * Fecha:       Thursday 04 de April de 2021 (14_40)
 * Version:     1.0-SNAPSHOT
 * .
 * Interface 'Mapper' MyBatis asociado a la entidad Usuario 
 *
 * Historia:    .
 *              20210415_1440 Generado por arq.gen, basado en los
 *              archivos fuente de Gustavo Arellano
 *
 */

package io.kebblar.petstore.api.mapper;

import java.util.List;
import java.sql.SQLException;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import io.kebblar.petstore.api.model.domain.Usuario;

/**
 * <p>Descripción:</p>
 * Interface 'Mapper' MyBatis asociado a la entidad Usuario 
 *
 * @author Gustavo A. Arellano
 * @version 1.0-SNAPSHOT
 */
@Repository
public interface UsuarioMapper {
    static final String CAMPOS = " id, correo, clave, creado, activo, acceso_negado_contador, instante_bloqueo, instante_ultimo_acceso, instante_ultimo_cambio_clave, regenera_clave_token, regenera_clave_instante ";

    @Results(id="UsuarioMap", value = {
            @Result(property = "id", column = "id"),
        @Result(property = "correo", column = "correo"),
        @Result(property = "clave", column = "clave"),
        @Result(property = "creado", column = "creado"),
        @Result(property = "activo", column = "activo"),
        @Result(property = "accesoNegadoContador", column = "acceso_negado_contador"),
        @Result(property = "instanteBloqueo", column = "instante_bloqueo"),
        @Result(property = "instanteUltimoAcceso", column = "instante_ultimo_acceso"),
        @Result(property = "instanteUltimoCambioClave", column = "instante_ultimo_cambio_clave"),
        @Result(property = "regeneraClaveToken", column = "regenera_clave_token"),
        @Result(property = "regeneraClaveInstante", column = "regenera_clave_instante")    
    })
    @Select("SELECT " + CAMPOS + " FROM usuario WHERE id = #{id} ") 
    Usuario getById(Usuario usuario) throws SQLException;

    @ResultMap("UsuarioMap")
    @Select("SELECT " + CAMPOS + " FROM usuario ") 
    List<Usuario> getAll() throws SQLException;
    
    @Insert("INSERT INTO usuario(id, correo, clave, creado, activo, acceso_negado_contador, instante_bloqueo, instante_ultimo_acceso, instante_ultimo_cambio_clave, regenera_clave_token, regenera_clave_instante) VALUES(#{id}, #{correo}, #{clave}, #{creado}, #{activo}, #{accesoNegadoContador}, #{instanteBloqueo}, #{instanteUltimoAcceso}, #{instanteUltimoCambioClave}, #{regeneraClaveToken}, #{regeneraClaveInstante} )")
    @Options(useGeneratedKeys=true, keyProperty="id", keyColumn = "id")
    int insert(Usuario usuario) throws SQLException;

    @Update("UPDATE usuario SET correo = #{correo}, clave = #{clave}, creado = #{creado}, activo = #{activo}, acceso_negado_contador = #{accesoNegadoContador}, instante_bloqueo = #{instanteBloqueo}, instante_ultimo_acceso = #{instanteUltimoAcceso}, instante_ultimo_cambio_clave = #{instanteUltimoCambioClave}, regenera_clave_token = #{regeneraClaveToken}, regenera_clave_instante = #{regeneraClaveInstante} WHERE id = #{id} )")
    int update(Usuario usuario) throws SQLException;

    @Delete("DELETE FROM usuario WHERE id = #{id} ") 
    int delete(int id) throws SQLException;

}
